file = open("SMSSpamCollection.txt", "r")

hamTextCounter = 0
hamWordCounter = 0

spamTextCounter = 0
spamWordCounter = 0

usklicnikCounter = 0

for line in file:
    words = line.split()
    if(words[0] == "ham"):
        hamTextCounter += 1
        hamWordCounter += len(words) - 1
    elif(words[0] == "spam"):
        spamTextCounter += 1
        spamWordCounter += len(words) - 1
        
        lastWord = words[len(words) - 1]
        lastSymbol = lastWord[len(lastWord) - 1]
        if lastSymbol == "!":
            usklicnikCounter += 1
        
print("Average number of words in ham texts: " + str(round((hamWordCounter / hamTextCounter),2)))
print("Average number of words in spam texts: " + str(round((spamWordCounter / spamTextCounter),2)))
print("The number of spam texts ending in \"!\" is: " + str(usklicnikCounter))