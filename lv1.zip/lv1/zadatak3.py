
list = []
while True:
    number = input("Enter a number: ")
    if number == 'Done':
        break
    try :
        num = int(number)
    except:
        print('Invalid Input')
        continue

    list.append(num)

print(len(list))
print("Srednja vrijednost: " + str(round(sum(list) / len(list), 2)))

print("Maksimalna vrijednost: " + str(max(list)))
print("Minimalna vrijednost: " + str(min(list)))
list.sort()
print(list)





