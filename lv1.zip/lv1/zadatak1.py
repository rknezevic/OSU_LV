
def total_euro(radni_sati, satnica):

    ukupno = radni_sati*satnica
    print("Ukupno: " + str(round(ukupno, 5)) + " eura")

radniSati = float(input("Radni sati: "))
satnica = float(input("eura/h: "))
total_euro(radniSati, satnica)


