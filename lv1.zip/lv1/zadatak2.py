try:
    ocjena = float(input("Unesite ocjenu između 0.0 i 1.0: "))
except ValueError:
    print("Broj nije unesen")
else:
    if ocjena < 0.0 or ocjena > 1.0:
        print("Uneseni broj nije u zadanom rasponu.")
    elif ocjena >= 0.9:
        print("A")
    elif ocjena >= 0.8 and ocjena < 0.9:
        print("B")
    elif ocjena >= 0.7 and ocjena < 0.8:
        print("C")
    elif ocjena >= 0.6 and ocjena < 0.7:
        print("D")
    else: 
        print("F")
